import time
import threading
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from urllib.parse import parse_qs, urlencode, urlsplit

import httpx
import jwt
from cryptography.hazmat.primitives.asymmetric import rsa
from chatgpt_login import AUTH, LoginAttempt, LoginError, access_token, disconnect, validate_identity


class LoginTests(unittest.TestCase):
    def test_refresh_and_revocation(self):
        session = {'client_id': 'oaiapp_test', 'access_token': 'old', 'refresh_token': 'old-refresh', 'expires_at': 0, 'scope': 'chatgpt.tokens.use.direct', '_refresh_lock': threading.Lock()}
        with patch('chatgpt_login.httpx.post') as post:
            post.return_value = SimpleNamespace(is_success=True, json=lambda: {'access_token': 'new', 'refresh_token': 'rotated', 'expires_in': 3600})
            self.assertEqual(access_token(session), 'new')
            self.assertEqual(session['refresh_token'], 'rotated')
            self.assertEqual(post.call_args.kwargs['data']['client_id'], 'oaiapp_test')
            self.assertNotIn('scope', post.call_args.kwargs['data'])
        with patch('chatgpt_login.httpx.get') as get, patch('chatgpt_login.httpx.post') as post:
            get.return_value.json.return_value = {'revocation_endpoint': AUTH + '/oauth/revoke'}
            post.return_value.status_code = 200
            self.assertTrue(disconnect(session))
            self.assertEqual(post.call_args.kwargs['data']['token'], 'rotated')
            get.return_value.json.return_value = {'revocation_endpoint': 'https://untrusted.example/revoke'}
            post.reset_mock()
            self.assertFalse(disconnect(session))
            post.assert_not_called()

    def test_callback_state_and_code_exchange(self):
        with patch('chatgpt_login.host_id', return_value='urn:uuid:test-host'):
            attempt = LoginAttempt()
        try:
            query = parse_qs(urlsplit(attempt.url).query)
            self.assertEqual(query['client_id'], ['dynamic_agent_client'])
            self.assertEqual(query['code_challenge_method'], ['S256'])
            self.assertIn('chatgpt.tokens.use.direct', query['scope'][0])
            bad = httpx.get(attempt.redirect + '?state=wrong&code=bad')
            self.assertEqual(bad.status_code, 400)
            self.assertFalse(attempt.done)
            with patch('chatgpt_login.httpx.post') as post, patch('chatgpt_login.validate_identity', return_value={'sub': 'account'}):
                post.return_value = SimpleNamespace(is_success=True, json=lambda: {'id_token': 'test', 'access_token': 'private', 'scope': 'chatgpt.tokens.use.direct'})
                response = httpx.get(attempt.redirect + '?' + urlencode({'state': attempt.state, 'code': 'one-use', 'client_id': 'oaiapp_test'}))
                self.assertEqual(response.status_code, 200)
                session = attempt.finish()
                self.assertEqual(session['client_id'], 'oaiapp_test')
                self.assertEqual(post.call_args.kwargs['data']['redirect_uri'], attempt.redirect)
                self.assertEqual(post.call_args.kwargs['data']['code_verifier'], attempt.verifier)
                with self.assertRaises(LoginError):
                    attempt.finish()
        finally:
            attempt.close()

    def test_identity_signature_audience_and_nonce(self):
        private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        claims = {'iss': AUTH, 'sub': 'account', 'aud': 'oaiapp_test', 'exp': time.time()+60, 'iat': time.time(), 'nonce': 'expected'}
        token = jwt.encode(claims, private, algorithm='RS256')
        with patch('chatgpt_login.jwt.PyJWKClient') as factory:
            factory.return_value.get_signing_key_from_jwt.return_value = SimpleNamespace(key=private.public_key())
            self.assertEqual(validate_identity(token, 'oaiapp_test', 'expected')['sub'], 'account')
            with self.assertRaises(LoginError):
                validate_identity(token, 'oaiapp_test', 'wrong')
            with self.assertRaises(jwt.InvalidAudienceError):
                validate_identity(token, 'other-client', 'expected')
            forged = jwt.encode(claims, rsa.generate_private_key(public_exponent=65537, key_size=2048), algorithm='RS256')
            with self.assertRaises(jwt.InvalidSignatureError):
                validate_identity(forged, 'oaiapp_test', 'expected')
