import io
import json
import unittest
import threading
import time
from pathlib import Path
from unittest.mock import patch, MagicMock
from types import SimpleNamespace
from streamlit.testing.v1 import AppTest
from core import ask, extract, explain_api_error, grade, validate_quiz, IncompleteResponseError

QUESTION = {'question': '광합성이 일어나는 곳은?', 'options': ['엽록체', '핵', '리보솜', '골지체'], 'answer': 0, 'explanation': '광합성은 엽록체에서 일어납니다.', 'source': '샘플 강의 · 문단 1'}
APP = str(Path(__file__).resolve().parents[1] / 'app.py')


class CoreTests(unittest.TestCase):
    def test_gemini_request_and_incomplete(self):
        with patch('openai.OpenAI') as factory:
            client = factory.return_value.__enter__.return_value
            client.chat.completions.create.return_value = SimpleNamespace(choices=[SimpleNamespace(finish_reason='stop', message=SimpleNamespace(content='노트'))])
            self.assertEqual(ask('gemini-test', 'gemini-3.1-flash-lite', '자료', '퀴즈', schema={'type': 'object'}, provider='gemini'), '노트')
            self.assertEqual(factory.call_args.kwargs['base_url'], 'https://generativelanguage.googleapis.com/v1beta/openai/')
            self.assertIn('response_format', client.chat.completions.create.call_args.kwargs)
            client.responses.create.assert_not_called()
            client.chat.completions.create.return_value.choices[0].finish_reason = 'length'
            with self.assertRaises(IncompleteResponseError):
                ask('gemini-test', 'model', '자료', '노트', provider='gemini')

    def test_chatgpt_stream_and_required_options(self):
        with patch('openai.OpenAI') as factory:
            client = factory.return_value.__enter__.return_value
            stream = client.responses.create.return_value.__enter__
            stream.return_value = iter([SimpleNamespace(type='response.output_text.delta', delta='정리'), SimpleNamespace(type='response.completed')])
            self.assertEqual(ask('oauth-test', 'account-model', '자료', '요약', provider='chatgpt'), '정리')
            options = client.responses.create.call_args.kwargs
            self.assertTrue(options['stream'])
            self.assertFalse(options['store'])
            self.assertNotIn('max_output_tokens', options)
            stream.return_value = iter([SimpleNamespace(type='response.output_text.delta', delta='미완료')])
            with self.assertRaises(IncompleteResponseError):
                ask('oauth-test', 'account-model', '자료', '요약', provider='chatgpt')

    def test_safe_api_diagnostics(self):
        import httpx
        import openai
        request = httpx.Request('POST', 'https://api.openai.com/v1/responses')
        for cls, status, code, expected in [
            (openai.RateLimitError, 429, 'insufficient_quota', '크레딧'),
            (openai.RateLimitError, 429, 'rate_limit_exceeded', '처리 한도'),
            (openai.AuthenticationError, 401, 'invalid_api_key', '인증'),
            (openai.NotFoundError, 404, 'model_not_found', '모델'),
            (openai.PermissionDeniedError, 403, None, '권한'),
        ]:
            exc = cls('secret sk-test-NEVER-DISPLAY lecture text', response=httpx.Response(status, request=request), body={'code': code})
            result = explain_api_error(exc)
            self.assertIn(expected, result)
            self.assertIn(str(status), result)
            self.assertNotIn('sk-test', result)
            self.assertNotIn('lecture text', result)
        self.assertIn('연결', explain_api_error(openai.APIConnectionError(request=request)))
        self.assertNotIn('sk-secret', explain_api_error(ValueError('sk-secret')))

    def test_text_and_encoding(self):
        self.assertIn('[강의.txt · 문단 2]', extract('강의.txt', '첫 문단\n\n둘째 문단'.encode()))
        self.assertIn('광합성', extract('강의.txt', '광합성'.encode('cp949')))

    def test_reject_empty_and_unknown(self):
        for name, data in [('a.txt', b''), ('a.txt', b'   '), ('a.exe', b'x')]:
            with self.assertRaises(ValueError):
                extract(name, data)

    def test_docx_and_pptx(self):
        from docx import Document
        from pptx import Presentation
        doc = Document()
        doc.add_paragraph('테스트 강의')
        doc.add_table(rows=1, cols=1).cell(0, 0).text = '표 안의 개념'
        buf = io.BytesIO()
        doc.save(buf)
        self.assertIn('표 안의 개념', extract('a.docx', buf.getvalue()))
        deck = Presentation()
        slide = deck.slides.add_slide(deck.slide_layouts[1])
        slide.shapes.title.text = '광합성'
        buf = io.BytesIO()
        deck.save(buf)
        self.assertIn('슬라이드 1', extract('a.pptx', buf.getvalue()))

    def test_quiz_validation_and_grading(self):
        questions = validate_quiz(json.dumps({'questions': [QUESTION]}), 1)
        self.assertEqual(grade(questions, {'0': 0}), [True])
        self.assertEqual(grade(questions, {}), [False])
        with self.assertRaises(ValueError):
            validate_quiz(json.dumps({'questions': [{**QUESTION, 'answer': 4}]}), 1)
        with self.assertRaises(ValueError):
            validate_quiz(json.dumps({'questions': [QUESTION]}), 3)


class ScreenTests(unittest.TestCase):
    def test_subscription_login_screen(self):
        app = AppTest.from_file(APP).run()
        self.assertEqual(app.selectbox(key='provider').value, 'chatgpt')
        app.checkbox[0].check().run()
        app.button(key='notesgenerate').click().run()
        self.assertTrue(any('로그인' in w.value for w in app.warning))
        session = {'access_token': 'fake-oauth', 'client_id': 'oaiapp_test', 'sub': 'test', 'account_label': '테스트 계정', 'expires_at': time.time()+3600, '_refresh_lock': threading.Lock()}
        # Simulate a previously validated local sign-in without authenticating.
        app.session_state['chatgpt_session'] = session
        app.session_state['chatgpt_models'] = [('model-from-account', '구독 모델')]
        app.run()
        self.assertFalse(app.exception)
        with patch('core.ask', return_value='구독으로 생성한 노트') as ask_mock:
            app.button(key='notesgenerate').click().run()
            self.assertEqual(ask_mock.call_args.kwargs['provider'], 'chatgpt')
            self.assertEqual(ask_mock.call_args.args[0], 'fake-oauth')

    def test_gemini_screen_and_key_isolation(self):
        app = AppTest.from_file(APP).run()
        app.selectbox(key='provider').select('gemini').run()
        app.text_input(key='gemini_key').set_value('fake-gemini').run()
        app.checkbox[0].check().run()
        with patch('core.ask', return_value='Gemini 노트') as ask_mock:
            app.button(key='notesgenerate').click().run()
            self.assertEqual(ask_mock.call_args.kwargs['provider'], 'gemini')
            self.assertEqual(ask_mock.call_args.args[0], 'fake-gemini')
        app.selectbox(key='provider').select('openai').run()
        self.assertNotEqual(app.text_input(key='openai_key').value, 'fake-gemini')
        self.assertFalse(app.exception)

    def test_empty_and_sample_screen(self):
        app = AppTest.from_file(APP).run()
        app.selectbox(key='provider').select('openai').run()
        self.assertFalse(app.exception)
        app.checkbox[0].check().run()
        self.assertFalse(app.exception)
        self.assertEqual(len(app.tabs), 5)
        app.button(key='quizgenerate').click().run()
        self.assertTrue(any('API 키' in w.value for w in app.warning))

    def test_generated_notes_and_quiz(self):
        app = AppTest.from_file(APP).run()
        app.selectbox(key='provider').select('openai').run()
        app.checkbox[0].check().run()
        app.text_input[0].set_value('test-key').run()
        with patch('core.ask', return_value='# 광합성 노트\n출처: 샘플 강의'):
            app.button(key='notesgenerate').click().run()
        self.assertFalse(app.exception)
        self.assertIn('광합성 노트', app.session_state['notes'])
        with patch('core.ask', return_value=json.dumps({'questions': [QUESTION]*3})):
            app.button(key='quizgenerate').click().run()
        self.assertFalse(app.exception)
        self.assertEqual(len(app.radio), 3)
        for radio in app.radio:
            radio.set_value(0)
        app.button(key='quizsubmit').click().run()
        self.assertFalse(app.exception)
        self.assertEqual(app.metric[0].value, '100점')

    def test_exam_expiry_and_document_reset(self):
        app = AppTest.from_file(APP).run()
        app.selectbox(key='provider').select('openai').run()
        app.checkbox[0].check().run()
        app.text_input[0].set_value('test-key').run()
        with patch('core.ask', return_value=json.dumps({'questions': [QUESTION]*3})):
            app.button(key='examgenerate').click().run()
        self.assertFalse(app.exception)
        app.session_state['exam_start'] = 0
        app.run()
        self.assertFalse(app.exception)
        self.assertTrue(app.session_state['exam_result']['expired'])
        self.assertEqual(app.metric[0].value, '0점')
        app.checkbox[0].uncheck().run()
        self.assertNotIn('exam', app.session_state)


if __name__ == '__main__':
    unittest.main()
